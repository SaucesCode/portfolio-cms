(function(g){g.__tsParticlesInternals=g.__tsParticlesInternals||{};g.__tsParticlesInternals.bundles=g.__tsParticlesInternals.bundles||{};g.__tsParticlesInternals.effects=g.__tsParticlesInternals.effects||{};g.__tsParticlesInternals.engine=g.__tsParticlesInternals.engine||{};g.__tsParticlesInternals.interactions=g.__tsParticlesInternals.interactions||{};g.__tsParticlesInternals.palettes=g.__tsParticlesInternals.palettes||{};g.__tsParticlesInternals.paths=g.__tsParticlesInternals.paths||{};g.__tsParticlesInternals.plugins=g.__tsParticlesInternals.plugins||{};g.__tsParticlesInternals.plugins=g.__tsParticlesInternals.plugins||{};g.__tsParticlesInternals.plugins.emittersShapes=g.__tsParticlesInternals.plugins.emittersShapes||{};g.__tsParticlesInternals.presets=g.__tsParticlesInternals.presets||{};g.__tsParticlesInternals.shapes=g.__tsParticlesInternals.shapes||{};g.__tsParticlesInternals.updaters=g.__tsParticlesInternals.updaters||{};g.__tsParticlesInternals.utils=g.__tsParticlesInternals.utils||{};g.__tsParticlesInternals.canvas=g.__tsParticlesInternals.canvas||{};g.__tsParticlesInternals.canvas=g.__tsParticlesInternals.canvas||{};g.__tsParticlesInternals.canvas.utils=g.__tsParticlesInternals.canvas.utils||{};g.__tsParticlesInternals.path=g.__tsParticlesInternals.path||{};g.__tsParticlesInternals.path=g.__tsParticlesInternals.path||{};g.__tsParticlesInternals.path.utils=g.__tsParticlesInternals.path.utils||{};var __tsProxyFactory=typeof Proxy!=="undefined"?function(obj){return new Proxy(obj,{get:function(target,key){if(!(key in target)){target[key]={};}return target[key];}});}:function(obj){return obj;};g.__tsParticlesInternals.bundles=__tsProxyFactory(g.__tsParticlesInternals.bundles);g.__tsParticlesInternals.effects=__tsProxyFactory(g.__tsParticlesInternals.effects);g.__tsParticlesInternals.interactions=__tsProxyFactory(g.__tsParticlesInternals.interactions);g.__tsParticlesInternals.palettes=__tsProxyFactory(g.__tsParticlesInternals.palettes);g.__tsParticlesInternals.paths=__tsProxyFactory(g.__tsParticlesInternals.paths);g.__tsParticlesInternals.plugins=__tsProxyFactory(g.__tsParticlesInternals.plugins);g.__tsParticlesInternals.plugins.emittersShapes=__tsProxyFactory(g.__tsParticlesInternals.plugins.emittersShapes);g.__tsParticlesInternals.presets=__tsProxyFactory(g.__tsParticlesInternals.presets);g.__tsParticlesInternals.shapes=__tsProxyFactory(g.__tsParticlesInternals.shapes);g.__tsParticlesInternals.updaters=__tsProxyFactory(g.__tsParticlesInternals.updaters);g.__tsParticlesInternals.utils=__tsProxyFactory(g.__tsParticlesInternals.utils);g.__tsParticlesInternals.canvas=__tsProxyFactory(g.__tsParticlesInternals.canvas);g.__tsParticlesInternals.path=__tsProxyFactory(g.__tsParticlesInternals.path);g.tsparticlesInternalExports=g.tsparticlesInternalExports||{};})(typeof globalThis!=="undefined"?globalThis:typeof window!=="undefined"?window:this);
/* Path v4.0.5 */
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@tsparticles/plugin-move'), require('@tsparticles/noise-field'), require('@tsparticles/simplex-noise')) :
    typeof define === 'function' && define.amd ? define(['exports', '@tsparticles/plugin-move', '@tsparticles/noise-field', '@tsparticles/simplex-noise'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.__tsParticlesInternals = global.__tsParticlesInternals || {}, global.__tsParticlesInternals.paths = global.__tsParticlesInternals.paths || {}, global.__tsParticlesInternals.paths.simplexNoise = global.__tsParticlesInternals.paths.simplexNoise || {}), global.__tsParticlesInternals.plugins.move, global.__tsParticlesInternals.noise.field, global.__tsParticlesInternals.simplex.noise));
})(this, (function (exports, pluginMove, noiseField, simplexNoise) { 'use strict';

    class SimplexNoiseGenerator extends noiseField.NoiseFieldGenerator {
        constructor(container) {
            const simplex = new simplexNoise.SimplexNoise();
            super(container, {
                noise4d: (x, y, z, w) => simplex.noise4d.noise(x, y, z, w),
                seed: seed => {
                    simplex.noise4d.seed(seed);
                },
            });
        }
    }

    const simplexNoisePathName = "simplexNoise";
    async function loadSimplexNoisePath(engine) {
        engine.checkVersion("4.0.5");
        await engine.pluginManager.register((e) => {
            pluginMove.ensureBaseMoverLoaded(e);
            e.pluginManager.addPathGenerator?.(simplexNoisePathName, container => {
                return Promise.resolve(new SimplexNoiseGenerator(container));
            });
        });
    }

    const globalObject = globalThis;
    globalObject.__tsParticlesInternals = globalObject.__tsParticlesInternals ?? {};
    globalObject.loadSimplexNoisePath = loadSimplexNoisePath;

    exports.loadSimplexNoisePath = loadSimplexNoisePath;
    exports.simplexNoisePathName = simplexNoisePathName;

}));
Object.assign(globalThis.window || globalThis, { loadSimplexNoisePath: (globalThis.__tsParticlesInternals.paths.simplexNoise || {}).loadSimplexNoisePath });
delete (globalThis.window || globalThis).tsparticlesInternalExports;
