import { ensureBaseMoverLoaded } from "@tsparticles/plugin-move";
import { SimplexNoiseGenerator } from "./SimplexNoiseGenerator.js";
export const simplexNoisePathName = "simplexNoise";
export async function loadSimplexNoisePath(engine) {
    engine.checkVersion("4.0.5");
    await engine.pluginManager.register((e) => {
        ensureBaseMoverLoaded(e);
        e.pluginManager.addPathGenerator?.(simplexNoisePathName, container => {
            return Promise.resolve(new SimplexNoiseGenerator(container));
        });
    });
}
