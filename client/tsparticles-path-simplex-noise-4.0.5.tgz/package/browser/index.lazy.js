export const simplexNoisePathName = "simplexNoise";
export async function loadSimplexNoisePath(engine) {
    engine.checkVersion("4.0.5");
    await engine.pluginManager.register(async (e) => {
        const { ensureBaseMoverLoaded } = await import("@tsparticles/plugin-move/lazy");
        ensureBaseMoverLoaded(e);
        e.pluginManager.addPathGenerator?.(simplexNoisePathName, async (container) => {
            const { SimplexNoiseGenerator } = await import("./SimplexNoiseGenerator.js");
            return new SimplexNoiseGenerator(container);
        });
    });
}
