import { loadSimplexNoisePath } from "./index.js";
const globalObject = globalThis;
globalObject.__tsParticlesInternals = globalObject.__tsParticlesInternals ?? {};
globalObject.loadSimplexNoisePath = loadSimplexNoisePath;
export * from "./index.js";
