import { type Engine } from "@tsparticles/engine";
export declare const simplexNoisePathName = "simplexNoise";
export declare function loadSimplexNoisePath(engine: Engine): Promise<void>;
