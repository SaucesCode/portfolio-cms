import type { Container } from "@tsparticles/engine";
import { NoiseFieldGenerator } from "@tsparticles/noise-field";
export declare class SimplexNoiseGenerator extends NoiseFieldGenerator {
    constructor(container: Container);
}
